import pandas as pd

# Load the datasets
churn_df = pd.read_csv('customer_churn.csv')
house_df = pd.read_csv('house_prices.csv')
sales_df = pd.read_csv('sales_data.csv')

# Inspect customer_churn.csv
print("--- Customer Churn Data ---")
print(churn_df.info())
print(churn_df.head())

# Inspect house_prices.csv
print("\n--- House Prices Data ---")
print(house_df.info())
print(house_df.head())

# Inspect sales_data.csv
print("\n--- Sales Data ---")
print(sales_df.info())
print(sales_df.head())
import matplotlib.pyplot as plt
import seaborn as sns

# Set visual style
sns.set_theme(style="whitegrid")

# 1. Sales Data Analysis
# Aggregating sales by Product and Region
sales_by_product = sales_df.groupby('Product')['Total_Sales'].sum().sort_values(ascending=False).reset_index()
sales_by_region = sales_df.groupby('Region')['Total_Sales'].sum().sort_values(ascending=False).reset_index()

# Plot Sales by Product
plt.figure(figsize=(10, 6))
sns.barplot(data=sales_by_product, x='Total_Sales', y='Product', palette='viridis')
plt.title('Total Sales by Product')
plt.xlabel('Total Sales ($)')
plt.ylabel('Product')
plt.tight_layout()
plt.savefig('sales_by_product.png')

# Plot Sales by Region
plt.figure(figsize=(10, 6))
sns.barplot(data=sales_by_region, x='Total_Sales', y='Region', palette='magma')
plt.title('Total Sales by Region')
plt.xlabel('Total Sales ($)')
plt.ylabel('Region')
plt.tight_layout()
plt.savefig('sales_by_region.png')

# 2. Customer Churn Analysis
# Churn rate by Contract type
churn_by_contract = churn_df.groupby('Contract')['Churn'].mean().reset_index()

plt.figure(figsize=(10, 6))
sns.barplot(data=churn_by_contract, x='Contract', y='Churn', palette='coolwarm')
plt.title('Churn Rate by Contract Type')
plt.ylabel('Average Churn Rate')
plt.tight_layout()
plt.savefig('churn_rate_by_contract.png')

# 3. House Prices Analysis
# Correlation between Area and Price
plt.figure(figsize=(10, 6))
sns.scatterplot(data=house_df, x='Area', y='Price', hue='Location', style='Property_Type', alpha=0.7)
plt.title('House Price vs Area (by Location)')
plt.xlabel('Area (sq ft)')
plt.ylabel('Price ($)')
plt.tight_layout()
plt.savefig('price_vs_area.png')

# Average Price by Location
plt.figure(figsize=(10, 6))
sns.boxplot(data=house_df, x='Location', y='Price', palette='Set2')
plt.title('Price Distribution by Location')
plt.tight_layout()
plt.savefig('price_by_location.png')

# Summary statistics for report
sales_summary = sales_df.describe()
churn_summary = churn_df['Churn'].value_counts(normalize=True)
house_summary = house_df.groupby('Location')['Price'].mean().sort_values(ascending=False)

print("Churn Rate Distribution:\n", churn_summary)
print("\nAverage House Price by Location:\n", house_summary)