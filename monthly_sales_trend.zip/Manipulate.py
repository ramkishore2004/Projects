import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load data
sales_df = pd.read_csv('sales_data (2).csv')
churn_df = pd.read_csv('customer_churn (1).csv')

# --- Data Cleaning & Preparation ---

# Date Conversion
sales_df['Date'] = pd.to_datetime(sales_df['Date'])
sales_df['Month_Num'] = sales_df['Date'].dt.month
sales_df['Month_Name'] = sales_df['Date'].dt.month_name()

# ID Standardization
sales_df['ID_Num'] = sales_df['Customer_ID'].str.extract('(\d+)').astype(int)
churn_df['ID_Num'] = churn_df['CustomerID'].str.extract('(\d+)').astype(int)

# Merge
merged_df = pd.merge(sales_df, churn_df, on='ID_Num', how='left')

# --- Analysis for Plots ---

# 1. Monthly Sales
monthly_sales = sales_df.groupby('Month_Num')['Total_Sales'].sum()
# Create labels for months
month_labels = [pd.to_datetime(str(m), format='%m').strftime('%B') for m in monthly_sales.index]

# 2. Top Customers
customer_sales = sales_df.groupby('Customer_ID')['Total_Sales'].sum().sort_values(ascending=False).head(5)

# 3. Product Sales
product_sales = sales_df.groupby('Product')['Total_Sales'].sum().sort_values(ascending=False)

# 4. Regional Sales
region_sales = sales_df.groupby('Region')['Total_Sales'].sum()

# --- Visualizations ---
sns.set_style("whitegrid")
plt.rcParams.update({'font.size': 12})

# Plot 1: Monthly Sales Trend
plt.figure(figsize=(10, 6))
sns.lineplot(x=month_labels, y=monthly_sales.values, marker='o', linewidth=3, color='#2ecc71')
plt.title('Monthly Revenue Trend (2024)', fontsize=16, fontweight='bold')
plt.ylabel('Revenue ($)')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('monthly_sales_trend.png')
plt.close()

# Plot 2: Top 5 Customers
plt.figure(figsize=(10, 6))
sns.barplot(x=customer_sales.values, y=customer_sales.index, palette='viridis')
plt.title('Top 5 Customers by Lifetime Value', fontsize=16, fontweight='bold')
plt.xlabel('Total Spent ($)')
plt.tight_layout()
plt.savefig('top_customers.png')
plt.close()

# Plot 3: Product Sales Distribution
plt.figure(figsize=(10, 6))
sns.barplot(x=product_sales.index, y=product_sales.values, palette='magma')
plt.title('Sales Performance by Product', fontsize=16, fontweight='bold')
plt.ylabel('Total Sales ($)')
plt.tight_layout()
plt.savefig('product_sales.png')
plt.close()

# Plot 4: Regional Sales Share
plt.figure(figsize=(8, 8))
plt.pie(region_sales.values, labels=region_sales.index, autopct='%1.1f%%', 
        colors=sns.color_palette('pastel'), startangle=140)
plt.title('Sales Distribution by Region', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('region_sales.png')
plt.close()

print("Graphs generated successfully.")