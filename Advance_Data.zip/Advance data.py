import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# 1. Data Loading & Cleaning
df = pd.read_csv('sales_data (2).csv')
df['Date'] = pd.to_datetime(df['Date'])
df = df.sort_values('Date')

# Define a cohesive color palette
colors = ["#2a9d8f", "#e9c46a", "#f4a261", "#e76f51"]
sns.set_theme(style="whitegrid", palette="viridis")

# ==========================================
# DAY 1-4: STATISTICAL SEABORN DASHBOARD
# ==========================================
fig_sns, axes = plt.subplots(2, 2, figsize=(16, 12))
fig_sns.suptitle('Sales Analytics: Statistical Overview', fontsize=22, fontweight='bold', y=0.98)

# 1. Price Distribution (Box Plot - Day 2)
sns.boxplot(ax=axes[0, 0], x='Product', y='Price', data=df, palette="Set2")
axes[0, 0].set_title('Price Ranges by Product Category', fontsize=14)

# 2. Sales Volume vs Revenue (Regression Plot - Day 2)
sns.regplot(ax=axes[0, 1], x='Quantity', y='Total_Sales', data=df, 
            scatter_kws={'alpha':0.6, 'color':'#264653'}, line_kws={'color':'#e76f51'})
axes[0, 1].set_title('Quantity vs. Total Revenue Correlation', fontsize=14)

# 3. Regional Sales Density (Violin Plot - Day 2)
sns.violinplot(ax=axes[1, 0], x='Region', y='Total_Sales', data=df, inner="quart", palette="pastel")
axes[1, 0].set_title('Sales Distribution by Geographic Region', fontsize=14)

# 4. Metric Correlation (Heatmap - Day 3)
corr = df[['Quantity', 'Price', 'Total_Sales']].corr()
sns.heatmap(ax=axes[1, 1], data=corr, annot=True, cmap='coolwarm', fmt=".2f", cbar=False)
axes[1, 1].set_title('Correlation Matrix (Price vs. Sales)', fontsize=14)

plt.tight_layout(rect=[0, 0.03, 1, 0.95])
plt.savefig('seaborn_statistical_report.png')

# ==========================================
# DAY 5-7: INTERACTIVE PLOTLY DASHBOARD
# ==========================================

# Create a master layout for the interactive dashboard
fig_dash = make_subplots(
    rows=2, cols=2,
    subplot_titles=("Daily Sales Revenue Trend", "Regional Market Share", 
                    "Product Performance (Revenue vs Qty)", "Sales Distribution"),
    specs=[[{"type": "xy"}, {"type": "domain"}],
           [{"type": "xy"}, {"type": "xy"}]]
)

# A. Daily Trend (Line/Area Chart)
df_daily = df.groupby('Date')['Total_Sales'].sum().reset_index()
fig_dash.add_trace(go.Scatter(x=df_daily['Date'], y=df_daily['Total_Sales'], 
                             name="Revenue", fill='tozeroy', line=dict(color='#2a9d8f')), row=1, col=1)

# B. Regional Share (Interactive Pie/Donut)
reg_data = df.groupby('Region')['Total_Sales'].sum().reset_index()
fig_dash.add_trace(go.Pie(labels=reg_data['Region'], values=reg_data['Total_Sales'], 
                         hole=.4, name="Region"), row=1, col=2)

# C. Product Performance (Bar Chart)
product_perf = df.groupby('Product')['Total_Sales'].sum().reset_index()
fig_dash.add_trace(go.Bar(x=product_perf['Product'], y=product_perf['Total_Sales'], 
                         marker_color='#f4a261', name="Revenue"), row=2, col=1)

# D. Sales Distribution (Histogram)
fig_dash.add_trace(go.Histogram(x=df['Total_Sales'], marker_color='#264653', name="Freq"), row=2, col=2)

# Global Styling
fig_dash.update_layout(
    height=900, 
    title_text="Executive Sales Performance Dashboard (Interactive)",
    showlegend=False,
    template='plotly_white'
)

# Export interactive files
fig_dash.write_html('final_interactive_dashboard.html')

print("Success! Project generated: 'seaborn_statistical_report.png' and 'final_interactive_dashboard.html'")